// index.js
const express = require('express');
const cors = require('cors');
require('dotenv').config();
const bodyParser = require('body-parser');
const path = require('path');

const { sendWhatsappMessage } = require('./services/whatsappService');
const { sendEmail } = require('./services/emailService');
const adminService = require('./services/adminService');
const statsService = require('./services/statsService');

const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');

const app = express();
const port = 3000;

app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// servir vistas estáticas
app.use('/static', express.static(path.join(__dirname, 'views')));

// Rutas públicas de vistas
app.get('/', (req, res) => res.sendFile(path.join(__dirname, 'views', 'login.html')));
app.get('/login', (req, res) => res.sendFile(path.join(__dirname, 'views', 'login.html')));
app.get('/admin', (req, res) => res.sendFile(path.join(__dirname, 'views', 'admin.html')));

// ========== MIDDLEWARE JWT ==========
function authenticateJWT(req, res, next) {
  const auth = req.header('authorization');
  if (!auth) return res.status(401).json({ error: 'Token faltante' });
  const parts = auth.split(' ');
  if (parts.length !== 2 || parts[0] !== 'Bearer') return res.status(401).json({ error: 'Formato de token inválido' });
  const token = parts[1];
  try {
    const payload = jwt.verify(token, process.env.ADMIN_JWT_SECRET || 'default_jwt_secret');
    req.admin = payload; // contiene username
    next();
  } catch (err) {
    return res.status(401).json({ error: 'Token inválido o expirado' });
  }
}

// =================== RUTAS DE ADMIN (API) ===================

app.get('/api-info', authenticateJWT, (req, res) => {
  res.sendFile(path.join(__dirname, 'views', 'api-info.html'));
});

// Login (admin) -> devuelve JWT
app.post('/api/admin/login', async (req, res) => {
  const { username, password } = req.body;
  if (!username || !password) return res.status(400).json({ error: 'Faltan username/password' });

  const admin = await adminService.getAdmin();
  if (!admin) return res.status(500).json({ error: 'No hay configuración de admin' });

  if (username !== admin.username) return res.status(401).json({ error: 'Credenciales inválidas' });

  const match = await bcrypt.compare(password, admin.passwordHash);
  if (!match) return res.status(401).json({ error: 'Credenciales inválidas' });

  const token = jwt.sign({ username: admin.username }, process.env.ADMIN_JWT_SECRET || 'default_jwt_secret', { expiresIn: '8h' });

  res.json({ token });
});

// Obtener configuración actual (solo username y API_KEY parcialmente)
app.get('/api/admin/config', authenticateJWT, async (req, res) => {
  const admin = await adminService.getAdmin();
  res.json({
    username: admin.username,
    apiKeyMasked: admin.apiKeyHash ? admin.apiKeyHash : '',
    domainUrl: admin.domainUrl || '',
    smtpHost: admin.smtpHost || '',
    smtpUser: admin.smtpUser || '',
    smtpPass: admin.smtpPass ? admin.smtpPass : '',
    smtpPort: admin.smtpPort || ''
  });
});

// Actualizar configuración: username, password (opcional), apiKey (opcional), domainUrl (opcional)
app.post('/api/admin/config', authenticateJWT, async (req, res) => {
  const { username, password, apiKey, domainUrl, smtpHost, smtpUser, smtpPass, smtpPort } = req.body;

  if (!username && !password && !apiKey && !domainUrl && !smtpHost && !smtpUser && !smtpPass && !smtpPort) {
    return res.status(400).json({ error: 'Nada para actualizar' });
  }

  try {
    await adminService.updateAdmin({ username, password, apiKey, domainUrl, smtpHost, smtpUser, smtpPass, smtpPort });
    return res.json({ ok: true, message: 'Configuración actualizada' });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: 'Error al actualizar configuración' });
  }
});

// Middleware para verificar API_KEY usando el hash en admin.json
async function verifyApiKeyHeader(req, res, next) {
  const apiKey = req.header('x-api-key');
  if (!apiKey) {
    return res.status(401).json({ error: 'No autorizado: API Key faltante' });
  }

  try {
    const valid = await adminService.compareApiKey(apiKey);
    if (!valid) {
      return res.status(401).json({ error: 'No autorizado: API Key inválida' });
    }
    next();
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: 'Error validando API Key' });
  }
}

// =================== RUTA PRINCIPAL (tu funcionalidad Jitsi) ===================
app.post('/jitsi-url', verifyApiKeyHeader, async (req, res) => {
  const { paciente, medico, numero, cedula, fecha, email } = req.body;

  if (!paciente || !medico || !numero || !cedula || !fecha) {
    return res.status(400).json({ error: 'Faltan los parámetros "paciente", "medico", "numero", "cedula" y/o "fecha"' });
  }

  const pacienteLimpio = paciente.trim().replace(/\s+/g, '-');
  const cedulaLimpio = cedula.trim().replace(/\s+/g, '-');
  const fechaLimpio = fecha.trim().replace(/\s+/g, '-');
  const medicoLimpio = medico.trim().replace(/\s+/g, '-');

  // Formatear fecha a dia-mes-año
  let fechaFormateada = fechaLimpio;
  if (/^\d{4}-\d{2}-\d{2}$/.test(fechaLimpio)) {
    const [año, mes, dia] = fechaLimpio.split('-');
    fechaFormateada = `${dia}-${mes}-${año}`;
  }

  const sala = `consulta-${medicoLimpio}-con-${pacienteLimpio}-${cedulaLimpio}-${fechaFormateada}`;

  // ===================== NUEVO: obtener domainUrl del admin =====================
  const admin = await adminService.getAdmin();
  const domainUrl = admin.domainUrl || process.env.JITSI_DOMAIN;

  const payload = {
    aud: process.env.JITSI_APP_ID,
    iss: process.env.JITSI_APP_ID,
    sub: domainUrl,   
    room: sala,
    exp: Math.floor(Date.now() / 1000) + (60 * 60 * 24), // válido 24 horas
  };

  const token = jwt.sign(payload, process.env.JITSI_APP_SECRET, { algorithm: 'HS256' });

  // Construir URL final usando domainUrl
  const url = `${domainUrl}/${sala}?jwt=${token}`;

  try {
    await statsService.incrementApiCalls();
    const whatsappStatus = await sendWhatsappMessage(numero, url, medico, paciente);

    let emailStatus = null;
    if (email) {
      try {
        await sendEmail(email, url);
        emailStatus = 'ok';
      } catch (e) {
        emailStatus = 'error';
      }
    }

    res.json({ url, whatsappStatus, emailStatus });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Error enviando WhatsApp' });
  }
});

// Ruta para estadísticas de llamadas a la API este mes
app.get('/api/admin/stats', authenticateJWT, async (req, res) => {
  try {
    const apiCalls = await statsService.getApiCallsThisMonth();
    res.json({ apiCalls });
  } catch (err) {
    res.status(500).json({ error: 'Error obteniendo estadísticas' });
  }
});

// Levantar servidor
app.listen(port, '0.0.0.0', async () => {
  await adminService.ensureAdminInitialized(); // crea admin.json si no existe
  console.log(`API corriendo en http://0.0.0.0:${port}`);
});
