const axios = require('axios');
require('dotenv').config();

// Configuración de entorno
const LOGIN_URL = process.env.LOGIN_URL;
const WHATSAPP_API_URL = process.env.WHATSAPP_API_URL;

const credentials = {
  username: process.env.API_USERNAME,
  password: process.env.API_PASSWORD,
  servicename: process.env.API_SERVICENAME,
  organizationname: process.env.API_ORGANIZATIONNAME
};

console.log("LOGIN_URL:", LOGIN_URL);
console.log("CREDENCIALES:", credentials);

// Variables para manejar el token
let accessToken = null;
let tokenExpiresAt = null;

// 🔑 Obtener token de acceso
async function getAccessToken() {
  const now = Math.floor(Date.now() / 1000);
  if (accessToken && tokenExpiresAt && now < tokenExpiresAt) return accessToken;

  try {
    const response = await axios.post(LOGIN_URL, credentials, {
      headers: { 'Content-Type': 'application/json' }
    });
    accessToken = response.data.access_token;
    tokenExpiresAt = now + response.data.expires_in - 60;
    console.log('🔑 Nuevo token obtenido');
    return accessToken;
  } catch (error) {
    console.error('❌ Error al obtener el token:', error.message);
    throw new Error('No se pudo autenticar con el servidor');
  }
}

// 📩 Enviar mensaje de WhatsApp
async function sendWhatsappMessage(numero, url, medico, paciente) {
  try {
    const token = await getAccessToken();

    await axios.post(
      WHATSAPP_API_URL,
      {
        CreateNonExistantContacts: true,
        CheckForActiveSession: false,
        Notification: {
          Messages: [
            {
              MeanType: { Name: "WhatsAppPremium" },
              Category: { Name: "AFTER" },
              Recipient: { Address: numero },
              Text: `📅 Consulta Dr. ${medico} con paciente ${paciente}\n\n🔗 Enlace de tu consulta médica:\n${url}\n\n⚠️ Recuerda conectarte unos minutos antes de tu hora agendada.`
            }
          ]
        }
      },
      {
        headers: {
          Authorization: `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      }
    );

    return 'Enviado por WhatsApp';
  } catch (error) {
    return `Error al enviar por WhatsApp: ${error.message}`;
  }
}

module.exports = { sendWhatsappMessage };
