const fs = require('fs').promises;
const path = require('path');

const DATA_DIR = path.join(__dirname, '..', 'data');
const STATS_FILE = path.join(DATA_DIR, 'stats.json');

async function ensureStatsInitialized() {
  await fs.mkdir(DATA_DIR, { recursive: true });
  try {
    await fs.access(STATS_FILE);
  } catch {
    await fs.writeFile(STATS_FILE, JSON.stringify({ apiCalls: {} }, null, 2), { mode: 0o600 });
  }
}

function getMonthKey() {
  const now = new Date();
  return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;
}

async function incrementApiCalls() {
  await ensureStatsInitialized();
  const raw = await fs.readFile(STATS_FILE, 'utf8');
  const stats = JSON.parse(raw);
  const monthKey = getMonthKey();
  stats.apiCalls[monthKey] = (stats.apiCalls[monthKey] || 0) + 1;
  await fs.writeFile(STATS_FILE, JSON.stringify(stats, null, 2), { mode: 0o600 });
}

async function getApiCallsThisMonth() {
  await ensureStatsInitialized();
  const raw = await fs.readFile(STATS_FILE, 'utf8');
  const stats = JSON.parse(raw);
  const monthKey = getMonthKey();
  return stats.apiCalls[monthKey] || 0;
}

module.exports = {
  incrementApiCalls,
  getApiCallsThisMonth,
  ensureStatsInitialized
};