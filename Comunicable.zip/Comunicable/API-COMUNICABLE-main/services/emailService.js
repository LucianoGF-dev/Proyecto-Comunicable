const nodemailer = require('nodemailer');
const adminService = require('./adminService');

async function sendEmail(to, url) {
    const admin = await adminService.getAdmin();
    const transporter = nodemailer.createTransport({
        host: admin.smtpHost || process.env.SMTP_HOST,
        port: admin.smtpPort || process.env.SMTP_PORT || 587,
        secure: false,
        auth: {
            user: admin.smtpUser || process.env.SMTP_USER,
            pass: admin.smtpPass || process.env.SMTP_PASS
        },
        tls: {
            ciphers: 'SSLv3'
        }
    });

    const mailOptions = {
        from: `"API Comunicable" <${admin.smtpUser || process.env.SMTP_USER}>`,
        to,
        subject: 'Enlace de llamada Jitsi',
        text: `Aquí está el enlace de la llamada: ${url}`,
        html: `<p>Aquí está el enlace de la llamada: <a href="${url}">${url}</a></p>`
    };

    try {
        const info = await transporter.sendMail(mailOptions);
        console.log('Email enviado:', info);
        return info;
    } catch (error) {
        console.error('Error enviando email:', error);
        throw error;
    }
}

module.exports = { sendEmail };