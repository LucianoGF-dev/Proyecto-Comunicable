// services/adminService.js
const fs = require('fs').promises;
const path = require('path');
const bcrypt = require('bcrypt');

const ADMIN_PATH = path.join(__dirname, '../data/admin.json');

async function ensureAdminInitialized() {
    try {
        await fs.access(ADMIN_PATH);
    } catch {
        // Si no existe, crea uno básico
        const defaultAdmin = {
            username: 'admin',
            passwordHash: await bcrypt.hash('admin', 10),
            apiKeyHash: await bcrypt.hash('123456', 10),
            domainUrl: '',
            smtpHost: '',
            smtpUser: '',
            smtpPass: '',
            smtpPort: '587'
        };
        await fs.writeFile(ADMIN_PATH, JSON.stringify(defaultAdmin, null, 2));
    }
}

async function getAdmin() {
    const data = await fs.readFile(ADMIN_PATH, 'utf8');
    return JSON.parse(data);
}

/**
 * updateAdmin: recibe { username?, password?, apiKey?, domainUrl? }
 * si password presente -> lo hashea y lo guarda
 * si apiKey presente -> lo hashea y lo guarda
 * si domainUrl presente -> lo guarda
 */
async function updateAdmin({ username, password, apiKey, domainUrl, smtpHost, smtpUser, smtpPass, smtpPort }) {
    const admin = await getAdmin();

    if (username) admin.username = username;
    if (domainUrl) admin.domainUrl = domainUrl;
    if (smtpHost !== undefined) admin.smtpHost = smtpHost;
    if (smtpUser !== undefined) admin.smtpUser = smtpUser;
    if (smtpPort !== undefined) admin.smtpPort = smtpPort;

    // Guardar smtpPass en texto plano 
    if (smtpPass !== undefined && smtpPass !== '') {
        admin.smtpPass = smtpPass;
    }

    if (password) {
        admin.passwordHash = await bcrypt.hash(password, 10);
    }

    if (apiKey) {
        admin.apiKeyHash = await bcrypt.hash(apiKey, 10);
    }

    await fs.writeFile(ADMIN_PATH, JSON.stringify(admin, null, 2));
    return admin;
}

/**
 * compareApiKey: compara el apiKey plano con el hash guardado
 */
async function compareApiKey(apiKey) {
    const admin = await getAdmin();
    if (!admin.apiKeyHash) return false;
    return bcrypt.compare(apiKey, admin.apiKeyHash);
}

module.exports = {
    ensureAdminInitialized,
    getAdmin,
    updateAdmin,
    compareApiKey
};
